﻿namespace DogRallyApp.ModelLayer.Model;

public class Extra : Item
{
}
