﻿namespace DogRallyApp.ModelLayer.Model;

public class DateCreate
{
    public int Id { get; set; }
    public DateTime Date { get; set; }
}
